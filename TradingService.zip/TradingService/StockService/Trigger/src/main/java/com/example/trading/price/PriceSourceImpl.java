package com.example.trading.price;

import java.util.HashMap;

public class PriceSourceImpl implements PriceSource {

	private PriceListener listener;
	private HashMap<String,Double> stockMap = new HashMap<>();
	private Double price;
	private boolean priceChangeFlag;
	private String security;
	@Override
	public void addPriceListener(PriceListener listener) {
		
		this.listener = listener;
	}

	@Override
	public void removePriceListener(PriceListener listener) {
		this.listener = null;
	}
	
	
	public void informPriceListener(){
		if(!priceChangeFlag)
			return;
		if(!priceChangeFlag && security == "Dell"){
			this.priceChangeFlag = false;
			listener.priceUpdate(security, stockMap.get(security));
		}	
	}
	
	public void priceChangeEvent(String security,double price){
		if(stockMap.containsKey(security)){
		this.priceChangeFlag = true;
		stockMap.put(security, price);
		informPriceListener();
		}
	}

}
