package com.example.trading.price;

import com.example.trading.execution.BuyExecutionService;

public class PriceListenerImpl implements PriceListener {

	private String security;
	private PriceSource source;
	private double price;
	private BuyExecutionService buyExecService;
	
	
	
	@Override
	public void priceUpdate(String security, double price) {
		
		this.security= security;
		this.price = price;
		
		if(this.price <100){
			buyExecService.buy(security, price, 100);
			System.out.println("100 shares purchased at price: "+price);
		}
		if(this.price >500){
			buyExecService.sell(security, price, 100);
			System.out.println("100 shares sold at price: "+price);
		}	
		
	}

}
