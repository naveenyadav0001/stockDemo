package com.example.trading.execution;

public class BuyExecutionServiceImpl implements BuyExecutionService{

	@Override
	public void buy(String security, double price, int volume) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sell(String security, double price, int volume) {
		// TODO Auto-generated method stub
		
	}

}
