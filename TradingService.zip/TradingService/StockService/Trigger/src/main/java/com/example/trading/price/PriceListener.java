package com.example.trading.price;

public interface PriceListener {
	void priceUpdate(String security, double price);
}
