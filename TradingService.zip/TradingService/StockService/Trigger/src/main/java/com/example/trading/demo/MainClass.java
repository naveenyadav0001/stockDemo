package com.example.trading.strategy;

import com.example.trading.price.PriceListener;
import com.example.trading.price.PriceListenerImpl;
import com.example.trading.price.PriceSource;
import com.example.trading.price.PriceSourceImpl;

public class MainClass{

	public static void main(String[] args) {
		PriceSourceImpl source = new PriceSourceImpl();
		
		PriceListener listener = new PriceListenerImpl();
		
		source.addPriceListener(listener);
		
		
		source.priceChangeEvent("Dell",58.00);
	}

}
